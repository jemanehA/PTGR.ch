import React, { useState, useEffect, useRef } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/home';
import CPM from './pages/cpm';
import PSRO from './pages/sro';
import Performance from './pages/performance';
import Digital from './pages/digitalasset';
import Forensic from './pages/Forensic';
import ISO from './pages/iso';
import PREISOS from './pages/preiso';
import CRYD from './pages/crypo';
import WEB3 from './pages/web3';
import About from './pages/Aboutus';
import Family from './pages/Family';
import WS from './pages/3ws';
import ISOsetup from './pages/ICOSetup';
import Metaverspage from './pages/metaverspage';
import CustodyPag from './pages/custodypage';
import TokenizatoPage from './pages/tokenizationpage';
import JobPage from './pages/Jobs';
import Event from './pages/Event';
import News from './pages/News';
import Blockchain from './pages/Blockchain';
import Swis from './pages/Swiscom';
import ChatBox from './components/ChatBox'; // Import the ChatBox component
import './styles/force.css';
import './crypto.css';
import CursorFollower from './components/CursorFollower';
import Blogs from './components/Blogs';
import BlogDetail from './components/BlogDetail'; // Import BlogDetail component
import TermsAndConditions from './components/TermsAndConditions';
import CookiePolicy from './components/CookiePolicy';
import DataPolicy from './components/Datapolicy';
import Disclaimer from './components/Disclaimer';
import Imprint from './components/Imprint';
import Partners from './components/Partners';
function App() {
  const headerRef = useRef(null); // Ref for the header element
  const [headerHeight, setHeaderHeight] = useState(0); // State to store header height

  // Calculate the header height on mount and window resize
  useEffect(() => {
    const calculateHeaderHeight = () => {
      if (headerRef.current) {
        setHeaderHeight(headerRef.current.offsetHeight); // Get the height of the header
      }
    };

    calculateHeaderHeight(); // Initial height calculation
    window.addEventListener('resize', calculateHeaderHeight); // Recalculate on resize

    // Cleanup the event listener on unmount
    return () => {
      window.removeEventListener('resize', calculateHeaderHeight);
    };
  }, []); // Empty dependency array ensures this runs once on mount

  return (
    <Router>
      <div className="cursor-follower-wrapper"><CursorFollower /></div>

      {/* App container for flex layout */}
      <div className="app-container">
        <Header ref={headerRef} />
        <ScrollToTop />
        <div className="main-content" style={{ marginTop: `110px` }}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/cpm" element={<CPM />} />
            <Route path="/sro" element={<PSRO />} />
            <Route path="/Performance" element={<Performance />} />
            <Route path="/Digital" element={<Digital />} />
            <Route path="/Forensic" element={<Forensic />} />
            <Route path="/iso" element={<ISO />} />
            <Route path="/preiso" element={<PREISOS />} />
            <Route path="/educationcertificate" element={<CRYD />} />
            <Route path="/WEB3" element={<WEB3 />} />
            <Route path="/Aboutus" element={<About />} />
            <Route path="/family" element={<Family />} />
            <Route path="/ws" element={<WS />} />
            <Route path="/isosetup" element={<ISOsetup />} />
            <Route path="/metaVereage" element={<Metaverspage />} />
            <Route path="/custodyage" element={<CustodyPag />} />
            <Route path="/Tokenizatoage" element={<TokenizatoPage />} />
            <Route path="/JobPage" element={<JobPage />} />
            <Route path="/Events" element={<Event />} />
            <Route path="/News" element={<News />} />
            <Route path="/Blockchain" element={<Blockchain />} />
            <Route path="/swis" element={<Swis />} />
            <Route path="/blogs" element={<Blogs />} />
            <Route path="/blog/:slug" element={<BlogDetail />} /> {/* Add route for blog details */}
            <Route path="/Terms" element={<TermsAndConditions />} />
            <Route path="/CookiePolicy" element={<CookiePolicy />} />
            <Route path="/Partners" element={<Partners />} />
            <Route path="/Datapolicy" element={<DataPolicy />} />
            <Route path="/Imprint" element={<Imprint />} />
            <Route path="/Disclaimer" element={<Disclaimer />} />
          </Routes>
        </div>
        <Footer />
        <ChatBox /> {/* Add the ChatBox component to be visible across all pages */}
      </div>
    </Router>
  );
}

// Component to handle scrolling to top on route change
const ScrollToTop = () => {
  const location = useLocation(); // Use location hook inside Router
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to the top on route change
  }, [location]);

  return null;
};

export default App;
