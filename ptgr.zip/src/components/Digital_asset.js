import React, { useState,useEffect } from "react";
import { Link } from 'react-router-dom';  // Ensure Link is imported
import '../styles/digitalasset.css';
import { Colors } from "chart.js";
const Digital_asset = () => {
  const [inView, setInView] = useState(false); // State to track visibility
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting); // Set state when the section is in view
      },
      { threshold: 0.5 } // Trigger when 50% of the section is in view
    );

    const section = document.getElementById('home'); // Select the section
    if (section) {
      observer.observe(section); // Start observing the section
    }

    return () => {
      if (section) {
        observer.unobserve(section); // Clean up the observer
      }
    };
  }, []);
  // State to control modal visibility
  const [isModalOpen, setModalOpen] = useState(false);

  // Function to open the modal
  const openModal = () => {
    console.log("Modal opened:", true);
    setModalOpen(true);
  };

  // Function to close the modal
  const closeModal = () => {
    console.log("Modal Close:", true);
    setModalOpen(false);
  };


  //working on showing a full list
  

  // Fetch crypto prices from CoinGecko API

  return (
    <div>
      <style>
        {`
          #servicetopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>

<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/global.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Digital Asset Advisory (SDAA)</p>
    <p className='headertit'>We provide guidance into the world of digital investing.
    <span className='headtit1'>Leading with Research and with care.</span></p>
    <Link to="/Aboutus">
          <a className="card-button">
            Get Started <i className="fas fa-play"></i>
          </a>
        </Link>
 
</div>




    </section>

    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Digital Asset Advisory</span>
</div>


<div class="container afterheading-section">
  <div class="row">
   
    <div class="col-xl-5 col-lg-5 afterheading-left">
      <div class="afterheading-title">
        <h2 class="afterheading-main-title">The entry into the world of digital investing</h2>
      </div>
    </div>
    
   
    <div class="col-xl-6 offset-xl-1 col-lg-7 afterheading-right">
      <div class="afterheading-content">
        <p class="afterheading-highlight">
        We create tailor-made investment portfolios so that our clients can best
        benefit from development in blockchain technology.
   </p>
        <p class="afterheading-description">
        Solid in-house research and external research collaborations are at the forefront of our investment philosophy. In our research, we rely not only on internal analytics resources but also cooperate with external professional research institutes.
        </p>
        <p class="afterheading-description">
        Solid in-house research and external research collaborations are at the forefront of our investment philosophy. In our research, we rely not only on internal analytics resources but also cooperate with external professional research institutes.
     </p>
      </div>
    </div>
  </div>
</div>



</div>
  );
};

export default Digital_asset;
