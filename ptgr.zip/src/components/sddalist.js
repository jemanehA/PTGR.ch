import React from "react";
import "../styles/Sddalist.css";

const SddaCards = () => {
  return (
    <div className="container ">
    </div>
  );
};

export default SddaCards;
