
import React, { useState,useEffect } from "react";
import '../styles/EventComponnent.css'; // Import the CSS file for styling
import { Link } from 'react-router-dom';  // Ensure Link is imported

const EventComponent = () => {
      const [inView, setInView] = useState(false); // State to track visibility
      useEffect(() => {
        const observer = new IntersectionObserver(
          ([entry]) => {
            setInView(entry.isIntersecting); // Set state when the section is in view
          },
          { threshold: 0.5 } // Trigger when 50% of the section is in view
        );
    
        const section = document.getElementById('home'); // Select the section
        if (section) {
          observer.observe(section); // Start observing the section
        }
    
        return () => {
          if (section) {
            observer.unobserve(section); // Clean up the observer
          }
        };
      }, []);

  return (
<div>
<style>
        {`
          #aboutustopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>
      <section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/Aboutus.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Events</p>
    <p className='headertit'>
  We host exceptional digital events.
  <span className='headtit1'>Leading with innovation and precision.</span>
</p>


 
</div>
</section>
    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Events</span>
</div>




<div class="container afterheading-section">
  <div class="row">
   
    <div class="col-xl-5 col-lg-5 afterheading-left">
      <div class="afterheading-title">
        <h2 class="afterheading-main-title">Upcoming Events </h2>
      </div>
    </div>
    
   
    <div class="col-xl-6 offset-xl-1 col-lg-7 afterheading-right">
      <div class="afterheading-content">
        <p class="afterheading-highlight">
        Don’t miss any more highlights. Be part of our events.
   </p>
        <p class="afterheading-description">
        We hold regular virtual events or on-site events. Once a month, we hold a Cryptomarket Talk, where we address the most important changes in the crypto market. In addition, we show monthly what our investment strategies are and how you can profit from the market with us.</p>
        <p class="afterheading-description">
        Be there and register directly at the link at the individual event that interests you.</p>
      </div>
    </div>
  </div>
</div>

<main className='eventmain'>
      <div className="container my-5">
        <h2 className="event-section-header text-center">Upcoming Events</h2>
        <div className="row">
          {/* Event 1 */}
          <div className="col-md-4 mb-4 dfdf">
            <div className="customcard1 event-card " style={{backgroundColor:'white'}}>
              <img
                src="/assets/images/event1.webp"
                className="card-img-top"
                alt="Event 1"
              />
              <div className="card-body">
                <h5 className="card-title event-card-title">Minds of the Future Event</h5>
                <p className="card-text event-card-date">January 15, 2025</p>
                <p className="card-text event-card-location">Zurich, Switzerland</p>
                <p className="card-text event-card-description">Connect with industry leaders and expand your professional network and knowledg
                </p>
                <div className="d-flex justify-content-between">
                  <a href="#" className="btn btn-primary event-card-btn">RSVP Now</a>
                  <a href="#" className="btn btn-secondary event-card-btn">Event Details</a>
                </div>
              </div>
            </div>
          </div>

          {/* Event 2 */}
          <div className="col-md-4 mb-4 dfdf">
          <div className="customcard1 event-card " style={{backgroundColor:'white'}}>
            <img
                src="/assets/images/event2.webp"
                className="card-img-top"
                alt="Event 1"
              />
              <div className="card-body">
                <h5 className="card-title event-card-title">Cryptocurrencies. NFTs. Metaverse.</h5>
                <p className="card-text event-card-date">February 10, 2025</p>
                <p className="card-text event-card-location">Geneva, Switzerland</p>
                <p className="card-text event-card-description">
                Connect with industry leaders and expand your professional network and knowledg
                </p>
                <div className="d-flex justify-content-between">
                  <a href="#" className="btn btn-primary event-card-btn">RSVP Now</a>
                  <a href="#" className="btn btn-secondary event-card-btn">Event Details</a>
                </div>
              </div>
            </div>
          </div>

          {/* Event 3 */}
          <div className="col-md-4 mb-4 dfdf">
          <div className="customcard1 event-card " style={{backgroundColor:'white'}}>
            <img
                src="/assets/images/event3.webp"
                className="card-img-top"
                alt="Event 1"
              />
              <div className="card-body">
                <h5 className="card-title event-card-title">HIC (HSG) x PTGR AG Collaboration</h5>
                <p className="card-text event-card-date">March 22, 2025</p>
                <p className="card-text event-card-location">Bern, Switzerland</p>
                <p className="card-text event-card-description">
                Connect with industry leaders and expand your professional network and knowledg
                </p>
                <div className="d-flex justify-content-between">
                  <a href="#" className="btn btn-primary event-card-btn">RSVP Now</a>
                  <a href="#" className="btn btn-secondary event-card-btn">Event Details</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          {/* Event 1 */}
          <div className="col-md-4 mb-4 dfdf">
          <div className="customcard1 event-card " style={{backgroundColor:'white'}}>
              <img
                src="/assets/images/event4.webp"
                className="card-img-top"
                alt="Event 1"
              />
              <div className="card-body">
                <h5 className="card-title event-card-title">Digital assets and the future</h5>
                <p className="card-text event-card-date">January 15, 2025</p>
                <p className="card-text event-card-location">Zurich, Switzerland</p>
                <p className="card-text event-card-description">Connect with industry leaders and expand your professional network and knowledg
                </p>
                <div className="d-flex justify-content-between">
                  <a href="#" className="btn btn-primary event-card-btn">RSVP Now</a>
                  <a href="#" className="btn btn-secondary event-card-btn">Event Details</a>
                </div>
              </div>
            </div>
          </div>

          {/* Event 2 */}
          <div className="col-md-4 mb-4 dfdf">
          <div className="customcard1 event-card " style={{backgroundColor:'white'}}>
            <img
                src="/assets/images/event5.jpg"
                className="card-img-top"
                alt="Event 1"
              />
              <div className="card-body">
                <h5 className="card-title event-card-title">Meet & Greet in Bucharest</h5>
                <p className="card-text event-card-date">February 10, 2025</p>
                <p className="card-text event-card-location">Geneva, Switzerland</p>
                <p className="card-text event-card-description">
                Connect with industry leaders and expand your professional network and knowledg
                </p>
                <div className="d-flex justify-content-between">
                  <a href="#" className="btn btn-primary event-card-btn">RSVP Now</a>
                  <a href="#" className="btn btn-secondary event-card-btn">Event Details</a>
                </div>
              </div>
            </div>
          </div>

          {/* Event 3 */}
          <div className="col-md-4 mb-4 dfdf">
          <div className="customcard1 event-card " style={{backgroundColor:'white'}}>
            <img
                src="/assets/images/event6.webp"
                className="card-img-top"
                alt="Event 1"
              />
              <div className="card-body">
                <h5 className="card-title event-card-title">Meet & Greet in Oslo Event</h5>
                <p className="card-text event-card-date">March 22, 2025</p>
                <p className="card-text event-card-location">Bern, Switzerland</p>
                <p className="card-text event-card-description">
                Connect with industry leaders and expand your professional network and knowledg
                </p>
                <div className="d-flex justify-content-between">
                  <a href="#" className="btn btn-primary event-card-btn">RSVP Now</a>
                  <a href="#" className="btn btn-secondary event-card-btn">Event Details</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>


</div>
  );
};

export default EventComponent;
