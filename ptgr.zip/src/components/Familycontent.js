import React, { useState ,useEffect } from 'react';
import BookConsultation from './BookConsultation'; // Importing the form component
import { Link } from 'react-router-dom';  // Ensure Link is imported
import '../styles/Aboutus.css'; // Import the CSS file for styling
const ForensicServices = () => {
    const [inView, setInView] = useState(false); // State to track visibility
      useEffect(() => {
        const observer = new IntersectionObserver(
          ([entry]) => {
            setInView(entry.isIntersecting); // Set state when the section is in view
          },
          { threshold: 0.5 } // Trigger when 50% of the section is in view
        );
    
        const section = document.getElementById('home'); // Select the section
        if (section) {
          observer.observe(section); // Start observing the section
        }
    
        return () => {
          if (section) {
            observer.unobserve(section); // Clean up the observer
          }
        };
      }, []);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };
    return (
        <div style={{paddingBottom:'10px'}}>

<style>
        {`
          #servicetopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>


<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/cam.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Family Crypto Savings Program</p>
    <p className='headertit'>We provide guidance into the world of digital investing.
    <span className='headtit1'>Leading with Research and with care.</span></p>
    <Link to="/Aboutus">
          <a className="card-button">
            Get Started <i className="fas fa-play"></i>
          </a>
        </Link>
 
</div>




    </section>
    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Family Crypto Savings Program</span>
</div>

<div class="container mt-5">
  <div class="row">
    <div class="col-md-8 mb-8">
  
    <div className="service-text">
      <h1 className="subtitle">What We Offer</h1>
      <p style={{textAlign:'justify'}}>
      The Family Crypto Savings Program is designed to help kids take their first steps into investing, all with the guidance and support of their parents. It creates a safe and structured way for families to work together, teaching children the basics of saving and investing while giving them hands-on experience in managing digital assets. Parents provide oversight and mentorship, ensuring the right strategies are in place, while kids learn valuable skills that prepare them for a future in an increasingly digital economy. It’s a collaborative and empowering way to build financial habits as a family.
      </p>

    </div>
    </div>
    <div class="col-md-4 mb-4">
     
    <div className="offer-icon">
      <img src="/assets/images/family.avif" alt="Offer Icon" className="offer-image"/>
    </div>
    </div>
  </div>
</div>








        <div className="ico-token-cta" style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
paddingBottom:'40px'
      }}>
                      <button className="cta-button" onClick={openModal}>
          Ready to Launch? Book a Consultation
        </button>
            </div>
            {/* Custom Modal */}
            {isModalOpen && (
        <div className="book-custom-modal">
  <div className="book-modal-content">
    <span className="book-close-button" onClick={closeModal}>
      &times;
    </span>
    <BookConsultation />
  </div>
</div>

      )}
      </div>
    );
  };
  
  export default ForensicServices;
