import React, { useEffect, useState } from "react";
import { Routes, Route, Link, useParams, useNavigate } from "react-router-dom";
import "../styles/Blogs.css";

const Blogs = () => {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await fetch("https://blogs.ptgr-test.com/serve-json.php");

        if (!response.ok) {
          throw new Error(`Failed to fetch blogs. Status: ${response.status}`);
        }

        const data = await response.json();
        setBlogs(data);
      } catch (error) {
        console.error("Error fetching blogs:", error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchBlogs();
  }, []);

  if (loading) {
    console.log("Loading state is true");
    return <div className="loading">Loading our blogs...</div>;
  }

  if (error) {
    return <div className="error">Error: {error}</div>;
  }

  return (
    <Routes>
      <Route path="/" element={<BlogList blogs={blogs} />} />
      <Route path="/blog/:slug" element={<BlogDetail blogs={blogs} />} />
    </Routes>
  );
};

const BlogList = ({ blogs }) => {
  return (
    <div className="container newscontainer">
      <style>
        {`
          #aboutustopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>
          <div className="container menudisplay breadcrumb">
        <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">News</span>
      </div>
     
      <div className="row">
        <div className="col-lg-9 col-md-12">
          {blogs[0] && (
            <div className="customcard1 featured-news">
              <img
                src={blogs[0].featuredImage}
                alt={blogs[0].title}
                className="featured-image"
              />
              <div className="featured-content">
                <h2>{blogs[0].title}</h2>
                <p className="text-muted">
                  By {blogs[0].author?.name || "Unknown"} |{" "}
                  {new Date(blogs[0].date).toDateString()}
                </p>
                <p>{blogs[0].excerpt}</p>
                <Link to={`/blog/${blogs[0].slug}`} className="btn btn-primary mt-3">
                  Read More
                </Link>
              </div>
            </div>
          )}
        </div>
        <div className="col-lg-3 col-md-12">
          <div className="news-list">
            {blogs.slice(1).map((blog) => (
              <Link key={blog.id} to={`/blog/${blog.slug}`} className="news-item-link">
                <div className="customcard1 news-item">
                  <div className="news-content">
                    <h5>{blog.title}</h5>
                    <p className="text-muted">
                      By {blog.author?.name || "Unknown"} |{" "}
                      {new Date(blog.date).toDateString()}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const BlogDetail = ({ blogs }) => {
  const { slug } = useParams();
  const navigate = useNavigate();

  const blog = blogs.find((b) => b.slug === slug);

  if (!blog) {
    return (
      <div className="container my-5 text-center">
        <h2>Blog not found!</h2>
        <button onClick={() => navigate("/")} className="btn btn-primary mt-3">
          Back to News
        </button>
      </div>
    );
  }

  return (
    <div className="container my-5">
      <button onClick={() => navigate("/")} className="btn btn-secondary mb-4">
        Back to News
      </button>
      <div className="customcard1 detailed-news">
        <img
          src={blog.featuredImage}
          alt={blog.title}
          className="detailed-image"
        />
        <div className="detailed-content">
          <h1>{blog.title}</h1>
          <p className="text-muted">
            By {blog.author?.name || "Unknown"} |{" "}
            {new Date(blog.date).toDateString()}
          </p>
          <p>{blog.content}</p>
        </div>
      </div>
    </div>
  );
};

export default Blogs;
