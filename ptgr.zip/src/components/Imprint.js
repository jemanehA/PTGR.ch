import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/Terms.css'; // Optional for additional tweaks
import { Link } from 'react-router-dom';

const Imprint = () => {
  return (
    <div className="container py-5">
            <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Imprint</span>
</div>
<div className='breakee'></div>
<div className="container py-0 afterheading-section">
        <div className="row">
          <div className="col-xl-4 col-lg-5 afterheading-left">
            <div className="afterheading-title">
              <h2 className="afterheading-main-title">
              Imprint
              </h2>
            </div>
          </div>
          <div className="col-xl-7 offset-xl-1 col-lg-8 afterheading-right">
            <h2>PTGR AG</h2>
            <p><strong>Dr. Pan Theo Grosse-Ruyken</strong></p>
    <p>Ibelweg 18a</p>
    <p>CH-6300 Zug</p>
    <p>SWITZERLAND</p>
    <p><a href="mailto:Info@ptgr.ch">Email: Info@ptgr.ch</a></p>
    <p>CRN: CH-170.3.046.884-0</p>
    <p>Place of jurisdiction: Zug, Switzerland</p>

    <p>&copy; 2023 PTGR AG. All rights reserved.</p>

    <p>All texts and graphics are protected by copyright.</p>
    <p>The approval, adoption and use of texts, images and all other data is prohibited or requires written consent from PTGR AG.</p>
          </div>
        </div>
      </div>







    </div>
  );
};

export default Imprint;
