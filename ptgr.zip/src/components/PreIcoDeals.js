import React, { useState,useEffect  } from 'react';
import BookConsultation from './BookConsultation';
import { Link } from 'react-router-dom';  // Ensure Link is imported
import '../styles/PreIcoDeals.css'; // You can create a separate CSS file for styling

const PreIcoDeals = () => {  const [inView, setInView] = useState(false); // State to track visibility
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting); // Set state when the section is in view
      },
      { threshold: 0.5 } // Trigger when 50% of the section is in view
    );

    const section = document.getElementById('home'); // Select the section
    if (section) {
      observer.observe(section); // Start observing the section
    }

    return () => {
      if (section) {
        observer.unobserve(section); // Clean up the observer
      }
    };
  }, []);

  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };
    return (
      <div>

<style>
        {`
          #servicetopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>



<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/cam.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Pre-ICO Deals</p>
    <p className='headertit'>We provide guidance into the world of digital investing.
    <span className='headtit1'>Leading with Research and with care.</span></p>
    <Link to="/Aboutus">
          <a className="card-button">
            Get Started <i className="fas fa-play"></i>
          </a>
        </Link>
 
</div>




    </section>
    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Pre-ICO Deals</span>
</div>


<div class="container mt-5">
  <div class="row">
    <div class="col-md-8 mb-8">
  
    <div className="service-text">
      <h1 className="subtitle">What We Offer</h1>
      <p style={{textAlign:'justify'}}>
        Exclusive Project Insights: We provide access to carefully hand-picked ICO/IDO projects, based on their innovation, team strength, and tokenomics viability. Together with cooperating external experts, we perform thorough analysis of all projects before we invest in them and offer them up to our clients.
      </p>
      <ul className="service-list" >
        <li>
          <span><strong>Comprehensive Project Analysis</strong></span>
        </li>
        <li>
          <span><strong>Step-by-Step Participation Guide</strong>: A thorough guide covering registration, eligibility, and the process for purchasing tokens, making complex procedures accessible and straightforward.</span>
        </li>
        <li>
          <span><strong>Strategic Investment Advice</strong>: Guidance on navigating the risks and opportunities of ICO/IDO investments, including access to attractive launch prices, understanding vesting conditions, and assessing potential gains against risks like dilution and total loss.</span>
        </li>
      </ul>
    </div>
    </div>
    <div class="col-md-4 mb-4">
     
    <div className="offer-icon">
      <img src="/assets/images/preiso.jpeg" alt="Offer Icon" className="offer-image"/>
    </div>
    </div>
  </div>
</div>




      <div className='strategydiv'>
      <div className="container mt-5 ">
        
        {/* Service Description */}


  

  <div className="row">
    <div className="col-12 col-md-12 ">
      <h3 className="subtitle">How It Works</h3>
      <p className="how-it-works-description">
        Our simple, investor-focused process guarantees clarity and confidence at every stage:
      </p>
      <div className="how-it-works-steps">
      <div className="how-it-works-step">
  <i className="fas fa-file-alt how-it-works-step-icon" aria-hidden="true" ></i>
  <span>
    <strong>Project Briefing:</strong> Receive a comprehensive overview of each carefully selected ICO/IDO project, highlighting its unique value proposition, potential market impact, and key financial metrics. This initial briefing gives you a complete picture, so you understand the investment opportunity right from the start.
  </span>
</div>

        <div className="how-it-works-step">
        <i className="fas fa-info-circle how-it-works-step-icon" aria-hidden="true"></i>
          <span><strong>Detailed Information & Fees:</strong> We provide all essential details, including tokenomics, roadmap, lock-up periods, vesting schedules, and associated fees. This transparency allows you to assess each project’s potential and risks before committing any funds.</span>
        </div>
        <div className="how-it-works-step">
        <i className="fas fa-calculator how-it-works-step-icon" aria-hidden="true"></i>
          <span><strong>Determine Your Investment Amount:</strong> Based on your personal goals and risk tolerance, decide on the amount you want to invest in the selected project. We support flexible investment levels, giving you control over your financial commitment.</span>
        </div>
        <div className="how-it-works-step">
        <i className="fas fa-dollar-sign how-it-works-step-icon" aria-hidden="true"></i>
          <span><strong>Investment Confirmation:</strong> Once you make your decision, we send an official confirmation of your investment with all relevant terms, providing you with a clear record of your entry position and expected outcomes.</span>
        </div>
        <div className="how-it-works-step">
        <i className="fas fa-bell how-it-works-step-icon" aria-hidden="true"></i>
          <span><strong>Token Listing Notification:</strong> We monitor the progress of each project and notify you promptly once the token is listed on a public exchange. This way, you stay informed and can track the project's market debut as it happens.</span>
        </div>
        <div className="how-it-works-step">
        <i className="fas fa-arrow-right how-it-works-step-icon" aria-hidden="true"></i>
          <span><strong>Token Transfer:</strong> After the listing, your pre-ICO tokens are securely transferred to your wallet. This step marks the completion of your investment entry, allowing you to engage with the token's ecosystem, trade, or hold as per your investment strategy.</span>
        </div>
      </div>

    </div>

  </div>


<div className="ico-token-cta" style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
paddingBottom:'40px'
      }}>
                                            <button className="cta-button" onClick={openModal}>
          Ready to Launch? Book a Consultation
        </button>
            </div>
            {/* Custom Modal */}
            {isModalOpen && (
        <div className="book-custom-modal">
  <div className="book-modal-content">
    <span className="book-close-button" onClick={closeModal}>
      &times;
    </span>
    <BookConsultation />
  </div>
</div>

      )}

      </div>

      </div>

      </div>
    );
  };
  
  export default PreIcoDeals;