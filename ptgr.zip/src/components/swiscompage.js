import React, {useState, useEffect } from 'react';
import { Link } from 'react-router-dom';  // Ensure Link is imported
import '../styles/BlockchainCourses.css';

const Swisscom = () => {
        const [inView, setInView] = useState(false); // State to track visibility
        useEffect(() => {
          const observer = new IntersectionObserver(
            ([entry]) => {
              setInView(entry.isIntersecting); // Set state when the section is in view
            },
            { threshold: 0.5 } // Trigger when 50% of the section is in view
          );
      
          const section = document.getElementById('home'); // Select the section
          if (section) {
            observer.observe(section); // Start observing the section
          }
      
          return () => {
            if (section) {
              observer.unobserve(section); // Clean up the observer
            }
          };
        }, []);
  const [password, setPassword] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [error, setError] = useState('');

  const correctPassword = "Swisscom2024"; // Example password

  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    if (password === correctPassword) {
      setIsAuthorized(true);
      setError('');
    } else {
      setError('Incorrect password. Please try again.');
    }
  };

  return (
    <div style={{marginBottom:'20px'}}>

<style>
        {`
          #educationtopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>
<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/education.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Swisscom Education Program</p>
    <p className='headertit'>Enroll in our <span className='headtit1'>Swisscom Education Program</span> Your gateway to mastering blockchain and cryptocurrency.</p>
 
</div>

    </section>

    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Swisscom Education Program</span>
</div>



      <div className="container mt-5">
        <h1 className="subtitle">Course Content Description</h1>
        <p>
          We provide tailored training on blockchain technology, empowering businesses to leverage real-world applications across industries such as finance, supply chain, and healthcare. With flexible learning formats, our program ensures your team is ready to lead in the digital transformation journey.
        </p>

        {/* Password Protected Section */}
        {!isAuthorized ? (
          <div className="password-section">
            <div className="form-container">
              <h2 className="form-header">Protected Content</h2>
              <form onSubmit={handlePasswordSubmit} className="password-form">
                <input
                  type="password"
                  className="password-input"
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button type="submit" className="password-button">
                  Unlock
                </button>
              </form>
              {error && <p className="error-message">{error}</p>}
            </div>
          </div>
        ) : (
          <div className="protected-content">
            <h3>Welcome to the Swisscom Exclusive Section</h3>
            <p>
              Here, you'll find advanced resources, industry insights, and materials specifically curated for your business needs.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Swisscom;
