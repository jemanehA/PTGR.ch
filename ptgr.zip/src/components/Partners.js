import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/Terms.css'; // Optional for additional tweaks
import { Link } from 'react-router-dom';
import Disclaimer from './Disclaimer';

const Partners = () => {
  return (
    <div className="container py-5">
            <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Partners</span>
</div>
<div className='breakee'></div>
<div className="container py-0 afterheading-section">
        <div className="row">
          <div className="col-xl-4 col-lg-5 afterheading-left">
            <div className="afterheading-title">
              <h2 className="afterheading-main-title">
              Strategic Partners
              </h2>
            </div>
          </div>
          <div className="col-xl-7 offset-xl-1 col-lg-8 afterheading-right">
          <p className="message-highlight">
          PTGR AG has a global network as well as international strategic research partners:
           </p>
       </div>
        </div>
        <div className=" partner-container row">
    <div className="col-xl-4 col-lg-5">
        <h4>Crypto Valley Member</h4>
        <p><a href="#" className="learn-more-link">Learn More</a></p>
    </div>
    <div className="col-xl-7 offset-xl-1 col-lg-8">
        <p>This is a description text about the company. It could include their services, mission, or any relevant information.</p>
        <img src="/assets/images/logo5.jpg.webp" alt="Company Logo" className="partner-logo" />
    </div>
</div>
<div className='breaks'></div>
<div className="partner-container row">
    <div className="col-xl-4 col-lg-5">
        <h4>The Geneva School of Diplomacy and International Relations (GSD)</h4>
        <p><a href="#" className="learn-more-link">Learn More</a></p>
    </div>
    <div className="col-xl-7 offset-xl-1 col-lg-8">
        
        <img src="/assets/images/10-44-53.png" alt="Company Logo" className="partner-logo" />
    </div>
</div>
<div className='breaks'></div>
<div className=" partner-container row">
    <div className="col-xl-4 col-lg-5">
        <h4>HSO - Wirtschafts- und Informatikschule</h4>
        <p><a href="#" className="learn-more-link">Learn More</a></p>
    </div>
    <div className="col-xl-7 offset-xl-1 col-lg-8">
        <p>he core competence of the HSO is the imparting of action- and practice-oriented education and training. Together with the HSO, interested parties can attend the course “Certificate in Blockchain & Crypto Eco-System HSO” on a quarterly basis starting in February 2023. We will take you further with this new educational offer and enable new professional and personal opportunities.</p>
        <img src="/assets/images/HSO.webp" alt="Company Logo" className="partner-logo" />
    </div>
</div>
<div className='breaks'></div>

      </div>







    </div>
  );
};

export default Partners;
