import React, {useState, useEffect } from 'react';
import { Link } from 'react-router-dom';  // Ensure Link is imported
import BookConsultation from './BookConsultation'; // Importing the form component
import '../styles/Aboutus.css'; // Import your styles

const Isows = () => {
          const [inView, setInView] = useState(false); // State to track visibility
          useEffect(() => {
            const observer = new IntersectionObserver(
              ([entry]) => {
                setInView(entry.isIntersecting); // Set state when the section is in view
              },
              { threshold: 0.5 } // Trigger when 50% of the section is in view
            );
        
            const section = document.getElementById('home'); // Select the section
            if (section) {
              observer.observe(section); // Start observing the section
            }
        
            return () => {
              if (section) {
                observer.unobserve(section); // Clean up the observer
              }
            };
          }, []);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div >

<style>
        {`
          #sw3ctopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>





<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="https://ptgr.ch/wp-content/uploads/2021/12/Error-Page.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Strategic Web 3.0 Consultancy</p>
    <p className='headertit'>Partner with us for <span className='headtit1'>Strategic Web 3.0 Consultancy</span> Your roadmap to harnessing the power of decentralized technologies.</p>

</div>

    </section>

    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Strategic Web 3.0 Consultancy</span>
</div>


<div className='container m-6'>
  <div className='wellcome'>
  <p>We are the one-stop shop destination for all our clients who need advanced digital asset services for their physical assets. Our main service offerings are the ones listed below.</p>
</div></div>


      <div className="forensic-services-section">
        <div className="forensic-container forensic-container-1">
          <div className="forensic-content">
            <div className="forensic-text-content">
              <h2 className="subtitle">Strategic ICO Execution</h2>
              <p className="forensic-text">
                We provide end-to-end support for the execution of Initial Coin
                Offerings (ICOs), ensuring every step aligns with your business
                goals. From market research and tokenomics to compliance and
                marketing, we focus on delivering a successful token sale that
                maximizes investor engagement and funding potential.
              </p>
            </div>
            <div className="forensic-image">
              <img src="/assets/images/iso.jpeg" alt="Crypto Fraud Protection" />
            </div>
          </div>
        </div>
      </div>

      <div
        className="ico-token-cta"
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          textAlign: 'center',
          marginBottom:'30px',
        }}
      >
        <button className="cta-button" onClick={openModal}>
          Ready to Launch? Book a Consultation
        </button>
      </div>

      {/* Custom Modal */}
      {isModalOpen && (
        <div className="book-custom-modal">
  <div className="book-modal-content">
    <span className="book-close-button" onClick={closeModal}>
      &times;
    </span>
    <BookConsultation />
  </div>
</div>

      )}
    </div>
  );
};

export default Isows;
