import React, { useState,useEffect } from "react";
import '../styles/Aboutus.css'; // Import the CSS file for styling
import AmazingPartners from '../components/AmazingPartners';
import { Link } from 'react-router-dom';  // Ensure Link is imported
import { Colors } from 'chart.js';

const AboutSection = () => {

    const [inView, setInView] = useState(false); // State to track visibility
    useEffect(() => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          setInView(entry.isIntersecting); // Set state when the section is in view
        },
        { threshold: 0.5 } // Trigger when 50% of the section is in view
      );
  
      const section = document.getElementById('home'); // Select the section
      if (section) {
        observer.observe(section); // Start observing the section
      }
  
      return () => {
        if (section) {
          observer.unobserve(section); // Clean up the observer
        }
      };
    }, []);
  useEffect(() => {
    // Call fetchCryptoData when the component mounts
    fetchCryptoData();
  }, []); // Empty dependency array means it runs only once, on mount

  // Function to safely manipulate DOM
  function fetchCryptoData() {
    try {
      // Safely attempt to get the element by ID
      const element = document.getElementById('section');  // The section with ID 'section'
      if (element) {
        element.style.backgroundColor = 'rgba(0, 0, 0, 0.5)'; // Example of DOM manipulation
      } else {
        console.warn('Element with ID "section" not found');
      }
    } catch (error) {
      // Catch and log any errors
      console.error('Error manipulating DOM:', error);
  
    }
  }
  const features = [
    {
      title: 'People',
      description: 'We look at each customer individually and provide all-round advice according to their needs.',
      icon: 'fas fa-user ',
    },
    {
      title: 'Passion',
      description: 'It is only thanks to our passion that we achieve the goals we set.',
      icon: 'fas fa-heart',
    },
    {
      title: 'Performance',
      description: 'Performance matters and we are happy to exceed targets wherever possible.',
      icon: 'fas fa-trophy',
    },
    {
      title: 'Portfolio management',
      description: 'We show you how to build your portfolio in the best possible and diversified way.',
      icon: 'fas fa-chart-line',
    },
    {
      title: 'Blockchain and Cryptos',
      description: 'We show you what the real key factors are and educate you professionally.',
      icon: 'fab fa-bitcoin',
    },
    {
      title: 'Trading',
      description: 'You will learn with us how intelligent and profit-oriented trading works.',
      icon: 'fas fa-exchange-alt',
    },
    {
      title: 'Tactical coins',
      description: 'We invest in projects with real use cases and high chances of success.',
      icon: 'fas fa-coins',
    },
    {
      title: 'Risk management',
      description: 'We show you how to profit from volatility when others lose.',
      icon: 'fas fa-shield-alt',
    },
  ];

  return (
<div>
<style>
{`
          #aboutustopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>



<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/Aboutus.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div 
    style={{
      content: '',
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(9, 19, 34, 0.4)', // Blue with 20% transparency
      zIndex: 2, // Make sure overlay appears above the video
    }}
  ></div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Who we are</p>
    <p className='headertit'>We provide guidance into the world of digital investing.
    <span className='headtit1'>Leading with Research and with care.</span></p>

 
</div>
</section>
    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Who we are</span>
</div>

      <div className="container py-5">
        <p>We are a team of professionals from investment banking, private banking, portfolio management, trading, IT, risk management, blockchain and cryptoassets.</p>
  <div className="row g-4"> {/* Bootstrap gap class for space between cards */}
    {features.map((feature, index) => (
      <div className="col-12 col-md-6 col-lg-3" key={index}> {/* 4 cards per row on large screens */}
        <div className=" h-100 ">
          <div className="cardabout" >
            <i
              className={`${feature.icon} custom-icon`}
              style={{ fontSize: '2rem' }}
            ></i>
            <h5 className="card-title">{feature.title}</h5>
            <p className="card-text">{feature.description}</p>
          </div>
        </div>
      </div>
    ))}
  </div>
</div>

<div className="panaboutusadvisory py-5">
  <div className="container">
    <div className="row text-center mb-5">
      <h2 className="middlesubwhite">Advisory Board - Who is behind PTGR AG?</h2>
    </div>

    <div className="row align-items-center">
      {/* CEO Image - Left Column */}
      <div className="col-md-4 text-center mb-4 mb-md-0">
        <img
          src="/assets/images/pan-final.jpg.webp"
          className="img-fluid rounded-3 shadow-lg border border-light "
          alt="CEO of PTGR AG - Dr. Pan Theo Grosse-Ruyken"
          style={{ maxWidth: '250px' }}
        />
        <h5 className="text-white mt-3">CEO of PTGR AG</h5>
        <h6 className="text-white" >Dr. Pan Theo Grosse-Ruyken</h6>

        {/* LinkedIn Icon Button */}
        <a 
          href="https://www.linkedin.com/in/dr-pan-grosse-ruyken-87278a92/?originalSubdomain=ch"
          className="btn btn-outline-light btn-lg mt-3"
          target="_blank"
          rel="noopener noreferrer"
        >
          <i className="fab fa-linkedin"></i> LinkedIn
        </a>
      </div>

      {/* CEO Message - Right Column */}
      <div className="col-md-8 text-white">
        <h4 className="mb-4 text-white text-center">Message from the CEO</h4>
        <p style={{ color: '#c9c2c2', textAlign: 'justify', lineHeight: '1.8' }}>
          <strong>Dr. Pan Theo Grosse-Ruyken</strong><br />
          PTGR stands for the initials of the founder and business owner: Dr. Pan Theo Grosse-Ruyken. He is the CEO of PTGR AG and an accomplished professional with significant experience in business development, strategic marketing, revenue growth, and supply chain management globally.
          <br />
          <br />
          I have had the privilege of steering several successful business initiatives across various industries, including wealth management and fintech, and I’m excited to lead PTGR AG into the future, leveraging innovative solutions, particularly in the areas of blockchain and digital assets.

          PTGR AG was officially founded in January 2022, after operating as a one-man business since 2014. With my experience and vision for sustainable growth, I aim to lead PTGR AG to new heights, ensuring that we continue to innovate and provide value to our clients and partners.
        </p>
      </div>
    </div>
  </div>
</div>




<div className='partnerss'>
<div className="container py-5">
  <div className="row text-center mb-5">
    <h2 className='subtitle'>Our Key to Success</h2>
  </div>
  <div className="row align-items-center">
    {/* First Column */}
    <div className="col-md-6">
    <h1 className="success-key">
        Our key to success? <span className="highlighted-text">Unique.</span>
      </h1>
      <h3 className="sub-heading">We value people, passion and performance.</h3>
      <div className="aboutusbtn">
      <a to="/cpm" className="cta-button">
          Contact Us 
        </a>
      </div>

    </div>
    {/* Second Column */}
    <div className="col-md-6">
      <h2 className="subtitlelittle">Why invest with us?</h2>
      <ul className="service-list">
        <li>
        
          <span>We have more than 7+ years of experience in the crypto market and thus the correspondingly well-founded knowledge to advise our customers in the highest quality.</span>
        </li>
        <li>
   
          <span>With us, each client is considered individually and advised on their needs and goals. Professionalism, passion and transparency are our keywords for your success.</span>
        </li>
        <li>
          
          <span>We are Crypto Valley Member and belong to the first movers and are a rising pioneer in the crypto market Switzerland.</span>
        </li>

      </ul>
    </div>
  </div>
</div>
</div>

<div className="container py-5 strategic-partners">
<AmazingPartners/>
</div>




</div>
  );
};

export default AboutSection;
