import React, { useState, useEffect } from "react";
import { Link } from 'react-router-dom';  // Ensure Link is imported
import '../styles/ptgr.css';

const PTGR = () => {
  const camTopMenu = document.getElementById("camtopmenu");

  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const cards = document.querySelectorAll('.card');
      const windowHeight = window.innerHeight;

      cards.forEach((card) => {
        const cardTop = card.getBoundingClientRect().top;
        if (cardTop < windowHeight - 100) {
          card.classList.add('fadeIn');
        } else {
          card.classList.remove('fadeIn');
        }
      });
    };

    window.addEventListener('scroll', handleScroll);

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting);
        if (camTopMenu) camTopMenu.style.backgroundColor = "rgba(0, 0, 0, 0.8)";
      },
      { threshold: 0.5 }
    );

    const section = document.getElementById('home');
    if (section) {
      observer.observe(section);
    }

    return () => {
      if (section) {
        observer.unobserve(section);
      }
    };
  }, []);

  useEffect(() => {
    fetchCryptoData();
  }, []);

  const fetchCryptoData = () => {
    try {
      const element = document.getElementById('section');
      if (element) {
        element.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
      } else {
        console.warn('Element with ID "section" not found');
      }
    } catch (error) {
      console.error('Error manipulating DOM:', error);
    }
  };

  const [isModalOpen, setModalOpen] = useState(false);

  const openModal = () => setModalOpen(true);
  const closeModal = () => setModalOpen(false);

  return (
    <div className="maincontentdiv">
      <style>
        {`
          #camtopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>
      <section className={`hero-section ${inView ? 'in-view' : ''}`}>
        <div className="video-container1">
          <video autoPlay muted loop playsInline id="hero-video">
            <source src="/assets/images/video/cam.MP4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>
        <div className="headingcontnetdiv container">
          <p className="page-indicator-text">PTGR Investment Strategies</p>
          <p className='headertit'>
            We provide guidance into the world of digital investing.
            <span className='headtit1'>Leading with Research and with care.</span>
          </p>
          <Link to="/Aboutus">
            <button className="card-button">
              Get Started <i className="fas fa-play"></i>
            </button>
          </Link>
        </div>
      </section>

      <div className="container menudisplay breadcrumb">
        <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">PTGR Investment Strategies</span>
      </div>

      <div className="container afterheading-section">
        <div className="row">
          <div className="col-xl-5 col-lg-5 afterheading-left">
            <div className="afterheading-title">
              <h2 className="afterheading-main-title">
                Professionally managed journey into the world of digital finance investment.
              </h2>
            </div>
          </div>
          <div className="col-xl-6 offset-xl-1 col-lg-7 afterheading-right">
            <div className="afterheading-content">
              <p className="afterheading-highlight">
                We will safely guide you into the world of digital finance by providing access to
                tailor-made portfolios well suited for every customer risk profile.
              </p>
              <p className="afterheading-description">
                In cooperation with professional research institutes, projects undergo an extensive
                due diligence process before taking on a strategic position.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="strategydiv">
        <div className="container ">
          <p className="content-description">
            At PTGR, we understand that every customer is unique. The most important differentiator is the appetite and tolerance for investment risk.
          </p>
          <div className="cards-container">
            <div className="card">
              <div className="card-icon">
                <i className="fas fa-lock custom-icon"></i>
              </div>
              <h4>PTGR Solid Strategy</h4>
              <p className="description">
              Targets stable growth with minimal risk, ideal for conservative investors. Features large-cap assets like Bitcoin and Ethereum for steady and reliable consistent returns.
              </p>
            </div>
            <div className="card">
              <div className="card-icon">
                <i className="fas fa-balance-scale custom-icon"></i>
              </div>
              <h4>PTGR Balanced Strategy</h4>
              <p className="description">
              A blend of stability and growth, aimed at moderate returns.
              Suitable for investors accepting some volatility for gains, including a mix of large- cap and promising mid-tier cryptos.
              </p>
            </div>
            <div className="card">
              <div className="card-icon">
                <i className="fas fa-rocket custom-icon"></i>
              </div>
              <h4>PTGR Growth Strategy</h4>
              <p className="description">
              High-growth approach for aggressive investors. Focuses on newer projects and high-potential DeFi tokens, accepting market volatility for significant returns.
              </p>
            </div>
          </div>
          <div className="ico-token-cta">
            <button className="cta-button" onClick={openModal}>Contact Us</button>
          </div>

          {isModalOpen && (
            <div id="contact-form-modal" className="modal open">
              <div className="modal-content">
                <span className="close-btn" onClick={closeModal}>&times;</span>
                <h2>Contact Us</h2>
                <form id="contact-form">
                  <input type="text" placeholder="Full Name" required />
                  <input type="email" placeholder="Email Address" required />
                  <textarea placeholder="Your Message" required></textarea>
                  <button type="submit">Send Message</button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PTGR;
