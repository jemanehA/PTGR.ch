import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";

const BlogDetail = () => {
  const { slug } = useParams(); // Get the slug from the URL
  const [blogs, setBlogs] = useState([]);
  const [blog, setBlog] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await fetch(`https://blogs.ptgr-test.com/serve-json.php`);
        const data = await response.json();
        setBlogs(data);
        const selectedBlog = data.find(b => b.slug === slug);
        if (selectedBlog) {
          setBlog(selectedBlog);
        } else {
          setError("Blog not found.");
        }
      } catch (err) {
        setError("Error fetching blog details.");
      }
      setLoading(false);
    };

    fetchBlogs();
  }, [slug]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  if (!blog) {
    return <div>Blog not found!</div>;
  }

  // Handle content rendering with the header and body as HTML
  const renderBlogContent = () => {
    const { header, body, media } = blog.content;

    return (
      <div><style>
      {`
        #aboutustopmenu {
          background-color: rgb(5, 21, 43);
          border-top-left-radius: 10px; /* Adjust the value as needed */
          border-top-right-radius: 10px; /* Adjust the value as needed */
        }
      `}
    </style>

        <div dangerouslySetInnerHTML={{ __html: header }} />
        <div dangerouslySetInnerHTML={{ __html: body }} />
        {media && media.length > 0 && (
          <div className="media-section">
            {media.map((item, index) => (
              <div key={index} className="media-item">
                {item.type === "image" && (
                  <img src={item.url} alt={item.alt} className="img-fluid" />
                )}
                {item.type === "video" && (
                  <video controls className="w-100">
                    <source src={item.url} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="container newscontainer">
      <div className="container menudisplay breadcrumb">
        <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <Link to="/blogs"> <span className="current-page">News</span></Link>
      </div>
      <div className="row">
        <div className="col-md-8">


          <div className="customcard1 detailed-news">
            <div className="detailed-content">
              <h1>{blog.title}</h1>
              <p className="text-muted">
                By {blog.author?.name || "Unknown"} |{" "}
                {new Date(blog.date).toDateString()}
              </p>
              {renderBlogContent()}
            </div>
          </div>
        </div>
        
        <div className="col-md-4">
          <div className="list-group mb-4">
            {blogs.map((blogItem) => (
              <Link 
                key={blogItem.slug} 
                to={`/blog/${blogItem.slug}`} 
                className="list-group-item list-group-item-action"
              >
                <h5>{blogItem.title}</h5>
                <p className="text-muted">
                  By {blogItem.author?.name || "Unknown"} | {new Date(blogItem.date).toDateString()}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogDetail;
