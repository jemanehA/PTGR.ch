import React, { useState,useEffect  } from 'react';
import { Link } from 'react-router-dom';  // Ensure Link is imported
import BookConsultation from './BookConsultation'; // Importing the form component
import '../styles/ForensicServices.css'; // Ensure this CSS is included
const ForensicServices = () => {
    const [inView, setInView] = useState(false); // State to track visibility
    useEffect(() => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          setInView(entry.isIntersecting); // Set state when the section is in view
        },
        { threshold: 0.5 } // Trigger when 50% of the section is in view
      );
  
      const section = document.getElementById('home'); // Select the section
      if (section) {
        observer.observe(section); // Start observing the section
      }
  
      return () => {
        if (section) {
          observer.unobserve(section); // Clean up the observer
        }
      };
    }, []);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };
    return (
        <div>

<style>
        {`
          #servicetopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>


<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/cam.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Forensic Services</p>
    <p className='headertit'>We provide guidance into the world of digital investing.
    <span className='headtit1'>Leading with Research and with care.</span></p>
    <Link to="/Aboutus">
          <a className="card-button">
            Get Started <i className="fas fa-play"></i>
          </a>
        </Link>
 
</div>




    </section>
    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Forensic Services</span>
</div>

<div class="container mt-5">
  <div class="row">
    <div class="col-md-8 mb-8">
  
    <div className="service-text">
      <h1 className="subtitle">What We Offer</h1>
      <p style={{textAlign:'justify'}}>
      <span><strong>Protecting Investors and Businesses from Digital Asset Fraud : </strong></span>
      As the digital asset landscape grows, so does the risk of fraudulent schemes, including phishing scams, fake ICOs, Ponzi schemes, and "rug pulls," which can lead to significant financial losses. PTGR AG’s forensic services are specifically designed to mitigate these risks, offering expert support to individuals and businesses affected by crypto fraud. </p>
      <ul className="service-list" >
        <li>
          <span><strong>Fraud Detection and Investigation</strong>: Identifying and investigating crypto fraud.</span>
        </li>
        <li>
          <span><strong>Asset Recovery Support</strong>: Assisting in recovering lost digital assets.</span>
        </li>
        <li>
          <span><strong>Risk Mitigation Strategies</strong>: Providing tailored advice on securing digital investments.</span>
        </li>
      </ul>
    </div>
    </div>
    <div class="col-md-4 mb-4">
     
    <div className="offer-icon">
      <img src="/assets/images/forensic.jpeg" alt="Offer Icon" className="offer-image"/>
     
    </div>
    </div>
  </div>
</div>


      
      <div className="forensic-services-section">
        {/* Container 1: Protecting Investors and Businesses */}
  
        {/* Container 2: Our Forensic Services Include */}
<div className="pad">
        <p >
            PTGR AG has a record of supporting customers in forensic services. We have documented cases where we assisted clients in tracking and documenting significant fraud-related losses, resulting in successful asset recovery. Our thorough investigation and legally compliant reports enabled clients to pursue justice confidently, providing additional evidence for court cases.
          </p>
  
          <p >
            If you’re a victim of potential crypto fraud or financial loss due to a scam, PTGR AG can provide tailored guidance and offer their assistance. Contact us for a consultation or to discuss a customized forensic report to support your case in court.
          </p>
          </div>
        </div>











            <div className='strategydiv'>
      <div className="container mt-5 ">
        
        {/* Service Description */}


  

  <div className="row">
    <div className="col-12 col-md-12 ">
      <h3 className="subtitle">Our Forensic Services</h3>

      <div className="how-it-works-steps">
      <div className="how-it-works-step">
      <i className="fas fa-search-dollar how-it-works-step-icon" aria-hidden="true"></i>

  <span>
    <strong>Comprehensive Fraud Analysis:</strong>     Our team of experts employs advanced blockchain analytics tools and Open Source Intelligence (OSINT) to trace fraudulent transactions, map asset flow, and identify patterns indicating malicious activity.
     
  </span>
</div>

        <div className="how-it-works-step">
        <i className="fas fa-gavel how-it-works-step-icon" aria-hidden="true"></i>

          <span><strong>Professional Reporting for Legal Proceedings:</strong> Providing informed guidance aligned with international regulatory landscapes, we help clients navigate AML and VASP licensing requirements within complex legal frameworks.</span>
        </div>
        <div className="how-it-works-step">
        <i className="fas fa-globe-americas how-it-works-step-icon" aria-hidden="true"></i>

          <span><strong>Global Regulatory Insight:</strong> Providing informed guidance aligned with international regulatory landscapes, we help clients navigate AML and VASP licensing requirements within complex legal frameworks.</span>
        </div>
      </div>

    </div>

  </div>


<div className="ico-token-cta" style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
paddingBottom:'40px'
      }}>
                                            <button className="cta-button" onClick={openModal}>
          Ready to Launch? Book a Consultation
        </button>
            </div>
            {/* Custom Modal */}
            {isModalOpen && (
        <div className="book-custom-modal">
  <div className="book-modal-content">
    <span className="book-close-button" onClick={closeModal}>
      &times;
    </span>
    <BookConsultation />
  </div>
</div>

      )}

      </div>

      </div>







            {/* Custom Modal */}
            {isModalOpen && (
        <div className="book-custom-modal">
  <div className="book-modal-content">
    <span className="book-close-button" onClick={closeModal}>
      &times;
    </span>
    <BookConsultation />
  </div>
</div>

      )}
      </div>
    );
  };
  
  export default ForensicServices;
