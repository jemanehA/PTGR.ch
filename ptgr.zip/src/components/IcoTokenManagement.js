import React, { useState,useEffect } from 'react';
import BookConsultation from './BookConsultation';
import { Link } from 'react-router-dom';  // Ensure Link is imported
import '../styles/IcoTokenManagement.css'; // Ensure this CSS file is included

const IcoTokenManagement = () => {

  const [inView, setInView] = useState(false); // State to track visibility
    useEffect(() => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          setInView(entry.isIntersecting); // Set state when the section is in view
        },
        { threshold: 0.5 } // Trigger when 50% of the section is in view
      );
  
      const section = document.getElementById('home'); // Select the section
      if (section) {
        observer.observe(section); // Start observing the section
      }
  
      return () => {
        if (section) {
          observer.unobserve(section); // Clean up the observer
        }
      };
    }, []);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };
    return (
      <div>

<style>
        {`
          #servicetopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>




<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/cam.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">ICO & Token Management Service</p>
    <p className='headertit'>We provide guidance into the world of digital investing.
    <span className='headtit1'>Leading with Research and with care.</span></p>
    <Link to="/Aboutus">
          <a className="card-button">
            Get Started <i className="fas fa-play"></i>
          </a>
        </Link>
 
</div>




    </section>
    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">ICO & Token Management Service</span>
</div>


<div class="container mt-5">
  <div class="row">
    <div class="col-md-8 mb-8">
  
    <div className="service-text">
      <h1 className="subtitle">What We Offer</h1>
      <p style={{textAlign:'justify'}}>
      PTGR AG offers comprehensive ICO (Initial Coin Offering) management services, transforming ambitious projects into successful ventures by providing tailored guidance through each stage of the ICO process. Our expertise in blockchain, fundraising, and regulatory compliance ensures seamless and efficient ICO launches, connecting projects with a global investor base.
      </p>

    </div>
    </div>
    <div class="col-md-4 mb-4">
     
    <div className="offer-icon">
      <img src="/assets/images/iso.jpeg" alt="Offer Icon" className="offer-image"/>
    </div>
    </div>
  </div>
</div>




      



        <div className="strategydiv">
            




            {/* Four Phases Container */}
            <div className="container mt-5">
  <h3 className="subtitle">Four Phases of PTGR AG’s ICO Management Process</h3>
  <div className="row">

    {/* Phase 1 */}
    <div className="col-md-3">
      <div className='prresios-phase' style={{backgroundColor:'#f1f6fa'}}>
      <i className="fas fa-clipboard-list prresios-token-phase-icon"></i>
      <h4>Phase 1: Project Assessment & Strategy Development</h4>
      <p >
        We define a clear vision, establish key objectives, and assess market potential. This stage includes crafting a whitepaper, identifying target audiences, and developing a unique value proposition.
      </p >
    </div></div>

    {/* Phase 2 */}
    <div className="col-md-3">
    <div className='prresios-phase' style={{backgroundColor:'#b9c9d8'}}>
      <i className="fas fa-gavel prresios-token-phase-icon"></i>
      <h4 style={{color:'#000000'}}>Phase 2: Legal & Regulatory Compliance</h4>
      <p style={{color:'#000000'}}>
        We ensure that all regulatory requirements are met, focusing on KYC/AML protocols and token classifications to build a legally compliant framework.
      </p>
    </div></div>

    {/* Phase 3 */}
    <div className="col-md-3">
    <div className='prresios-phase' style={{backgroundColor:'#a7bed4'}}>
      <i className="fas fa-bullhorn prresios-token-phase-icon"></i>
      <h4>Phase 3: Marketing & Community Engagement</h4>
      <p style={{color:'#000000'}}>
        We design targeted marketing campaigns, utilizing content marketing, social media outreach, and community engagement to build a strong investor community.
      </p>
    </div></div>

    {/* Phase 4 */}
    <div className="col-md-3">
    <div className='prresios-phase' style={{backgroundColor:'#8daccc'}}>
      <i className="fas fa-hand-holding-usd prresios-token-phase-icon"></i>
      <h4 style={{color:'#000000'}}>Phase 4: Token Sale & Fundraising Execution</h4>
      <p style={{color:'#000000'}}>
        We manage the token issuance process, ensuring secure and transparent transactions, while maximizing fundraising potential.
      </p></div>
    </div>

  </div>
</div>




            {/* Why PTGR AG Section */}
            <div className="ico-token-container ico-token-container-3">
                <h3 className="middlesub">Why PTGR AG for ICO Management?</h3>
                <p className="ico-token-description">
                    PTGR AG combines in-depth blockchain expertise with a strategic fundraising approach, guiding clients through each phase to launch a successful and compliant ICO. Our track record and resources ensure sustainable growth and investor engagement.
                </p>
            </div>

            {/* Call-to-Action Section */}

            <div className="ico-token-cta" style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
paddingBottom:'40px'
      }}>
                        <button className="cta-button" onClick={openModal}>
          Ready to Launch? Book a Consultation
        </button>
            </div>
        
        </div>

            {/* Custom Modal */}
            {isModalOpen && (
        <div className="book-custom-modal">
  <div className="book-modal-content">
    <span className="book-close-button" onClick={closeModal}>
      &times;
    </span>
    <BookConsultation />
  </div>
</div>

      )}
        </div>
    );
}

export default IcoTokenManagement;
