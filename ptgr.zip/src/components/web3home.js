import React, {useState, useEffect } from 'react';
import PayPal from "./PayPal";
import { Link } from 'react-router-dom';  // Ensure Link is imported
import '../styles/CertifiedExpertCryptoProgram.css'; // Create this CSS file for styles

const Web3home = () => {
        const [inView, setInView] = useState(false); // State to track visibility
        useEffect(() => {
          const observer = new IntersectionObserver(
            ([entry]) => {
              setInView(entry.isIntersecting); // Set state when the section is in view
            },
            { threshold: 0.5 } // Trigger when 50% of the section is in view
          );
      
          const section = document.getElementById('home'); // Select the section
          if (section) {
            observer.observe(section); // Start observing the section
          }
      
          return () => {
            if (section) {
              observer.unobserve(section); // Clean up the observer
            }
          };
        }, []);
  const [isModalOpen, setModalOpen] = useState(false);

  const handleModalClose = (e) => {
    if (e.target.classList.contains('paypal-modal-overlay')) {
      setModalOpen(false);
    }
  };
  useEffect(() => {
    // Call fetchCryptoData when the component mounts
    fetchCryptoData();
  }, []); // Empty dependency array means it runs only once, on mount

  // Function to safely manipulate DOM
  function fetchCryptoData() {
    try {
      // Safely attempt to get the element by ID
      const element = document.getElementById('section');  // The section with ID 'section'
      if (element) {
        element.style.backgroundColor = 'rgba(0, 0, 0, 0.5)'; // Example of DOM manipulation
      } else {
        console.warn('Element with ID "section" not found');
      }
    } catch (error) {
      // Catch and log any errors
      console.error('Error manipulating DOM:', error);
  
    }
  }
  return (
    <div style={{marginBottom:'10px'}}>
      <style>
        {`
          #educationtopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>


<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/education.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">Web 3.0 Power Sessions</p>
    <p className='headertit'>Enroll in our <span className='headtit1'>Web 3.0 Power Sessions</span> Your gateway to mastering blockchain and cryptocurrency.</p>
 
</div>

    </section>

    <div className="container menudisplay breadcrumb">
  <Link to="/" className="homemenu">Home</Link> <span className="separator">&gt;</span> <span className="current-page">Web 3.0 Power Sessions</span>
</div>

    <div className="container mt-5">
      <h1 className="subtitle">Course Content Description</h1>
      <p>
      Empower yourself with expert-led sessions on the transformative
          potential of Web 3.0. Explore blockchain ecosystems, passive income
          strategies, decentralized finance (DeFi), and the future of sustainable
          investing. Gain insights into crypto trends, market cycles, and the
          tools to identify and combat scams with forensic expertise.
      </p>

      <div className="row">
  {/* Course 1 */}
  <div className="col-md-4">
    <div className="web3card">
      <img
        src="/assets/images/wealth.webp"
        alt="Digital Wealth Management"
        className="web3card-img-top"
      />
      <div className="web3card-body">
        <h5 className="web3card-title">Digital Wealth and Asset Management</h5>
        <p className="web3card-text">
          Learn how to manage assets digitally with modern tools and techniques.
        </p>
      </div>
    </div>
  </div>

  {/* Course 2 */}
  <div className="col-md-4">
    <div className="web3card">
      <img
        src="/assets/images/blockchai.png"
        alt="Blockchain Ecosystem"
        className="web3card-img-top"
      />
      <div className="web3card-body">
        <h5 className="web3card-title">Blockchain Ecosystem &amp; Emergent Technologies</h5>
        <p className="web3card-text">
          Dive into the world of blockchain, exploring emerging technologies and applications.
        </p>
      </div>
    </div>
  </div>

  {/* Course 3 */}
  <div className="col-md-4">
    <div className="web3card">
      <img
        src="/assets/images/passive.png"
        alt="Passive Income Management"
        className="web3card-img-top"
      />
      <div className="web3card-body">
        <h5 className="web3card-title">Passive Income Management</h5>
        <p className="web3card-text">
          Strategies for building and managing passive income streams effectively.
        </p>
      </div>
    </div>
  </div>

  {/* Course 4 */}
  <div className="col-md-4">
    <div className="web3card">
      <img
        src="/assets/images/crypto.jpeg"
        alt="Crypto Trends"
        className="web3card-img-top"
      />
      <div className="web3card-body">
        <h5 className="web3card-title">Crypto Trends &amp; Market Cycles</h5>
        <p className="web3card-text">
          Analyze crypto market cycles and trends to make informed decisions.
        </p>
      </div>
    </div>
  </div>

  {/* Course 5 */}
  <div className="col-md-4">
    <div className="web3card">
      <img
        src="/assets/images/defi.jpg"
        alt="DeFi"
        className="web3card-img-top"
      />
      <div className="web3card-body">
        <h5 className="web3card-title">DeFi (Decentralized Distributed Finance)</h5>
        <p className="web3card-text">
          Understand decentralized finance and how to navigate its ecosystem.
        </p>
      </div>
    </div>
  </div>

  {/* Course 6 */}
  <div className="col-md-4">
    <div className="web3card">
      <img
        src="/assets/images/sustain.jpg"
        alt="Sustainable Investing"
        className="web3card-img-top"
      />
      <div className="web3card-body">
        <h5 className="web3card-title">Sustainable Impact Investing</h5>
        <p className="web3card-text">
          Learn how to invest sustainably, balancing profitability, social impact, and long-term growth.
        </p>
      </div>
    </div>
  </div>

  {/* Course 7 */}
  <div className="col-md-4">
    <div className="web3card">
      <img
        src="/assets/images/fore.jpg"
        alt="Crypto Scams"
        className="web3card-img-top"
      />
      <div className="web3card-body">
        <h5 className="web3card-title">Crypto Scams &amp; Forensic Services</h5>
        <p className="web3card-text">
          Identify and avoid crypto scams while leveraging forensic services.
        </p>
      </div>
    </div>
  </div>
</div>


  {/* Other Course Content */}
  <div className="ico-token-cta" style={{ textAlign: 'center' }}>
    <button className="cta-button" onClick={() => setModalOpen(true)}>
      Book Now
    </button>
  </div>

  {/* Modal for PayPal */}
  {isModalOpen && (
    <div className="paypal-modal-overlay show" onClick={handleModalClose}>
  <div className="paypal-modal-content" onClick={(e) => e.stopPropagation()}>
    <button className="paypal-close-button" onClick={() => setModalOpen(false)}>
      ✖
    </button>
    <h2>Complete Your Payment</h2>

    {/* Transaction Details */}
    <div className="transaction-details">
      <p><strong>Order Summary:</strong></p>
      <ul>
        <li>Item: <span>Web 3.0 Power Sessions</span></li>
        <li>Price: <span>$CHF 1.00</span></li>
        <li>Tax: <span>CHF 1.00</span></li>
        <li><strong>Total:</strong> <span>CHF 1.00</span></li>
      </ul>
    </div>

    {/* User Instructions */}
    <div className="payment-instructions">
      <p>Please review your order details above. Click "Pay with PayPal" to proceed with payment. You will be redirected to PayPal's secure platform to complete the process.</p>
    </div>

    {/* PayPal Component */}
    <div className="paypal-component">
      <PayPal />
    </div>

    {/* Support Contact */}
    <div className="support-info">
      <p>Need help? Contact us at <a href="mailto:support@example.com">info@ptgr.ch</a></p>
    </div>
  </div>
</div>

  )}
    </div>
  </div>
  );
};

export default Web3home;
