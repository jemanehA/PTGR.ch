import React, { useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
import '../styles/InvestmentPerformance.css';

const InvestmentPerformance = () => {
  useEffect(() => {
    // Any custom functionality to be run on component mount (e.g., setting up animations, etc.)
  }, []);

  const chartData = {
    labels: ['12/1/2023', '1/1/2024', '2/1/2024', '3/1/2024', '4/1/2024', '5/1/2024', '6/1/2024', '7/1/2024', '8/1/2024', '9/1/2024', '10/1/2024', '11/1/2024'],
    datasets: [
      {
        label: 'Bitcoin',
        data: [37740, 42466, 42672, 63012, 70719, 61112, 68732, 61446, 64625, 57969, 63723, 62384],
        borderColor: '#FF9900',
        backgroundColor: '#FF9900',
        fill: false,
        tension: 0.4,
        borderWidth: 2,
      },
      {
        label: 'Solid',
        data: [100000, 115976, 117552, 170649, 207776, 167190, 203169, 193821, 180789, 168493, 164086, 169873],
        borderColor: '#007bff',
        backgroundColor: '#007bff',
        fill: false,
        tension: 0.4,
        borderWidth: 2,
      },
      {
        label: 'Balanced',
        data: [100000, 125770, 129917, 192282, 228394, 172236, 203403, 171925, 166208, 156295, 153923, 173823],
        borderColor: '#9B1B30',
        fill: false,
        backgroundColor: '#9B1B30',
        tension: 0.4,
        borderWidth: 2,
      },
      {
        label: 'Growth',
        data: [100000, 131596, 136078, 223466, 293015, 215150, 238908, 197845, 176169, 139357, 146928, 156732],
        borderColor: '#000000',
        fill: false,
        backgroundColor: '#000000',
        tension: 0.4,
        borderWidth: 2,
      }
    ]
  };

  // Calculate percentage change for each circle (using end value compared to the initial value)
  const calculatePercentage = (data) => {
    const initialValue = data[0];
    const finalValue = data[data.length - 1];
    return ((finalValue - initialValue) / initialValue) * 100;
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      tooltip: {
        mode: 'index',
        intersect: false,
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Date'
        }
      },
      y: {
        title: {
          display: true,
          text: 'Value (in USD)'
        }
      }
    }
  };

  return (
    <div className="container">
      {/* Chart Section */}
      <div className="chart-container">
  <Line data={chartData} options={chartOptions} />
</div>

      {/* Performance Circles Section */}
      <div className="circle-container d-flex justify-content-evenly mt-5 mb-5 flex-wrap">
        <div className="circle1 bitcoin">
          <div className="circle1-bar" style={{ '--progress': `${calculatePercentage(chartData.datasets[0].data).toFixed(2)}%` }}></div>
          <div className="circle1-text">
            Bitcoin
            <div className="circle1-percentage">{calculatePercentage(chartData.datasets[0].data).toFixed(2)}%</div>
          </div>
        </div>
        <div className="circle1 solid">
          <div className="circle1-bar" style={{ '--progress': `${calculatePercentage(chartData.datasets[1].data).toFixed(2)}%` }}></div>
          <div className="circle1-text">
            Solid
            <div className="circle1-percentage">{calculatePercentage(chartData.datasets[1].data).toFixed(2)}%</div>
          </div>
        </div>
        <div className="circle1 balanced">
          <div className="circle1-bar" style={{ '--progress': `${calculatePercentage(chartData.datasets[2].data).toFixed(2)}%` }}></div>
          <div className="circle1-text">
            Balanced
            <div className="circle1-percentage">{calculatePercentage(chartData.datasets[2].data).toFixed(2)}%</div>
          </div>
        </div>
        <div className="circle1 growth">
          <div className="circle1-bar" style={{ '--progress': `${calculatePercentage(chartData.datasets[3].data).toFixed(2)}%` }}></div>
          <div className="circle1-text">
            Growth
            <div className="circle1-percentage">{calculatePercentage(chartData.datasets[3].data).toFixed(2)}%</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvestmentPerformance;
