import React, { useState,useEffect } from "react";
import { Link } from 'react-router-dom';  // Ensure Link is imported
import "../styles/cryptoAssetManagement.css"; // Make sure you have a corresponding CSS file

const CryptoAssetManagement = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [inView, setInView] = useState(false); // State to track visibility
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting); // Set state when the section is in view
      },
      { threshold: 0.5 } // Trigger when 50% of the section is in view
    );

    const section = document.getElementById('home'); // Select the section
    if (section) {
      observer.observe(section); // Start observing the section
    }

    return () => {
      if (section) {
        observer.unobserve(section); // Clean up the observer
      }
    };
  }, []);
  useEffect(() => {
    // Call fetchCryptoData when the component mounts
    fetchCryptoData();
  }, []); // Empty dependency array means it runs only once, on mount

  // Function to safely manipulate DOM
  function fetchCryptoData() {
    try {
      // Safely attempt to get the element by ID
      const element = document.getElementById('section');  // The section with ID 'section'
      if (element) {
        element.style.backgroundColor = 'rgba(0, 0, 0, 0.5)'; // Example of DOM manipulation
      } else {
        console.warn('Element with ID "section" not found');
      }
    } catch (error) {
      // Catch and log any errors
      console.error('Error manipulating DOM:', error);
  
    }
  }
  return (
    <div>

<style>
        {`
          #camtopmenu {
            background-color: rgb(5, 21, 43);
            border-top-left-radius: 10px; /* Adjust the value as needed */
            border-top-right-radius: 10px; /* Adjust the value as needed */
          }
        `}
      </style>

  


<section className={`hero-section ${inView ? 'in-view' : ''}`}>
      <div className="video-container1">
        <video autoPlay muted loop playsInline id="hero-video">
        <source src="/assets/images/video/cam.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className=" headingcontnetdiv container">
  
    <p className="page-indicator-text">PTGR is the SRO</p>
    <p className='headertit'>We provide guidance into the world of digital investing.
    <span className='headtit1'>Leading with Research and with care.</span></p>
    <Link to="/Aboutus">
          <a className="card-button">
            Get Started <i className="fas fa-play"></i>
          </a>
        </Link>
 
</div>
</section>







    <div className="container menudisplay breadcrumb">
  <Link to="/">Home</Link> <span className="separator">&gt;</span> <span className="current-page">PTGR is the SRO</span>
</div>


<div class="container afterheading-section">
  <div class="row">
   
    <div class="col-xl-5 col-lg-5 afterheading-left">
      <div class="afterheading-title">
        <h2 class="afterheading-main-title">PTGR AG Becomes Self-Regulated Organization (SRO)</h2>
      </div>
    </div>
    
   
    <div class="col-xl-6 offset-xl-1 col-lg-7 afterheading-right">
      <div class="afterheading-content">
        <p class="afterheading-highlight">
        We are proud to share that starting March 2025 (date TBC), PTGR AG will
officially become a Self-Regulated Organization (SRO).
   </p>
        <p class="afterheading-description">
        As a Self-Regulated Organization (SRO), we operate with structured autonomy,
adhering to the high standards set by the Swiss Financial Market Supervisory
Authority (FINMA). Our goal is to foster trust and ensure regulatory compliance.
The responsibilities of an SRO are multifaceted: maintaining strict internal
controls while proactively addressing evolving regulatory changes. </p>
<p className="afterheading-lessnot">For more on FINMA&#39;s regulations, visit <a href="https://www.finma.ch/en/">https://www.finma.ch/en/</a>.</p>
      </div>
    </div>
  </div>
</div>




<div className="strategydiv">
<div className="container mt-5 " style={{paddingBottom:'10px'}}>
  <h4 className="middlesub">Our Commitment to Self-Regulation</h4>
  <p className="main-text">
    Our SRO status underscores our dedication to providing a safe, compliant, and transparent environment. By independently anticipating regulatory needs and adhering to FINMA’s strict guidelines, we strengthen client confidence, operational security, and financial integrity.
  </p>
  <div className="finma-info-container">
  <p className="finma-description">
    For more on FINMA's regulations, visit  
    <a href="https://www.finma.ch/en/" target="_blank" className="finma-link">
    &nbsp;&nbsp;FINMA's Official Website
    </a>.
  </p>
  <img src="/assets/images/FINMALogo.png" alt="FINMA Logo" className="finma-logo" />
</div>



</div>


  </div>
  <section class="core-functions-section">
    <h4 class="section-title">Core Functions and Responsibilities</h4>
    <div class="core-functions">
      <div class="function-card">
        <div class="function-icon">
          <img src="/assets/images/strategic.webp" alt="AML" />
        </div>
        <h5>Anti-Money Laundering (AML) Compliance</h5>
        <p>We conduct ongoing risk assessments, monitor transactions, and implement robust anti-money laundering practices, overseen by a dedicated compliance team.</p>
      </div>
  
      <div class="function-card">
        <div class="function-icon">
          <img src="/assets/images/risk.jpeg" alt="Risk-Based Supervision" />
        </div>
        <h5>Risk Assessment and Compliance<br></br></h5>
        <p>We monitor and assess emerging financial and operational risks, applying targeted controls and immediate response strategies.</p>
      </div>
  
      <div class="function-card">
        <div class="function-icon">
          <img src="/assets/images/tra.jpg" alt="Transparent Governance" />
        </div>
        <h5>Transparent Governance</h5>
        <p>We commit to accessible communication on policies and standards, ensuring transparency to partners and clients.</p>
      </div>
  
      <div class="function-card">
        <div class="function-icon">
          <img src="/assets/images/aud.jpeg" alt="Audits and Reporting" />
        </div>
        <h5>Regular Audits and Reporting</h5>
        <p>We voluntarily undergo external audits and provide compliance reports to FINMA, maintaining financial and operational standards.</p>
      </div>
  
      <div class="function-card">
        <div class="function-icon">
          <img src="/assets/images/ada.jpeg" alt="Adaptation and Proactivity" />
        </div>
        <h5>Continuous Adaptation and Proactivity</h5>
        <p>We continuously review and update our regulatory framework to stay ahead of changes in financial laws and market risks.</p>
      </div>
    </div>
  </section>
  

  <div class="insurance-assets-section text-center p-4 bg-light shadow-sm rounded">
 
  <div class="assets-icon-container mx-auto">
    <i className="fas fa-shield-alt icon-shield text-primary"></i>
  </div>
 
  <h4 class="middlesub ">Insurance for Assets</h4>

  <p class="main-text">
    As PTGR becomes the licensed SRO, this means the liquid assets deposited with us are insured in Switzerland by Esisuisse up to 100,000 CHF, and all invested assets are protected.
  </p>
</div>




  </div> 
  );
};

export default CryptoAssetManagement;
