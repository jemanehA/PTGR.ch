import React from 'react';
import About from '../components/Aboutus1';
const Aboutt = () => {
  return (
    <div>
    <About/>
    </div>
  );
};

export default Aboutt;
