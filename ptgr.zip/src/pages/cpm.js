import React from 'react';
import PTGR from '../components/PTGR';
import MSRO from '../components/rsoheader';
import PER from '../components/PerformanceOverview';
const CPM = () => {
  return (
    <div>
    <PTGR/>
    {/* <MSRO/> */}
    {/* <PER/> */}
    </div>
  );
};

export default CPM;
