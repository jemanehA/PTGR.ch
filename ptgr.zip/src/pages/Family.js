import React from 'react';
import ForensicServices from '../components/Familycontent';
const Family = () => {
  return (
    <div>
    <ForensicServices/>
    </div>
  );
};

export default Family;
