import React from 'react';
import Digital_asset from '../components/Digital_asset';
import Sddalist from '../components/CryptoConsultingCards';
import CardCarousel from '../components/CardCarousel';
const Digital = () => {
  return (
    <div>
    <Digital_asset/>
    <Sddalist/>
    {/* <CardCarousel/> */}
    </div>
  );
};

export default Digital;
