import React from 'react';
import BlockchainCourses from '../components/BlockchainCourses';
// import CourseSection from '../components/CourseSection';
const Blockchain = () => {
  return (
    <div>
    <BlockchainCourses/>
    {/* <CourseSection/> */}
    </div>
  );
};

export default Blockchain;
