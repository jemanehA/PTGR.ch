import React from 'react';
import Jobs from '../components/JobComponnent';
const Job = () => {
  return (
    <div>
    <Jobs/>

    </div>
  );
};

export default Job;
