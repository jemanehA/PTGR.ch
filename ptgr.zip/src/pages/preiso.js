import React from 'react';
import PREISOO from '../components/PreIcoDeals';
const PREISO = () => {
  return (
    <div>
    <PREISOO/>
    </div>
  );
};

export default PREISO;
