import React from 'react';
import CRyptoo from '../components/CertifiedExpertCryptoProgram';
// import CourseSection from '../components/CourseSection';
const CRYPTO = () => {
  return (
    <div>
    <CRyptoo/>
    {/* <CourseSection/> */}
    </div>
  );
};

export default CRYPTO;
