import React from 'react';
import ISO from '../components/IcoTokenManagement';
const ISOO = () => {
  return (
    <div>
    <ISO/>
    </div>
  );
};

export default ISOO;
