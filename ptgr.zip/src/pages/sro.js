import React from 'react';
import MSRO from '../components/rsoheader';
const SRO = () => {
  return (
    <div>
    <MSRO/>
    </div>
  );
};

export default SRO;
