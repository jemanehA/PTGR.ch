import React from 'react';
import Jobs from '../components/EventComponent';
const Event = () => {
  return (
    <div>
    <Jobs/>
    </div>
  );
};

export default Event;
