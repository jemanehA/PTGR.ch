import React from 'react';
import Swiscom from '../components/swiscompage';
const Swis = () => {
  return (
    <div>
    <Swiscom/>
    </div>
  );
};

export default Swis;
