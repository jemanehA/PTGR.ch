import React from 'react';
import ForensicServices from '../components/ForensicServices';
const Forensic = () => {
  return (
    <div>
    <ForensicServices/>
    </div>
  );
};

export default Forensic;
