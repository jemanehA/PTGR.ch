import React from 'react';
import Web3home from '../components/web3home';
const WEB3 = () => {
  return (
    <div>
    <Web3home/>
    </div>
  );
};

export default WEB3;
