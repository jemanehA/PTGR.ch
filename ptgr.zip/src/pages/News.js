import React from 'react';
import Newscomponent from '../components/Newscomponent';
const News = () => {
  return (
    <div>
    <Newscomponent/>
    </div>
  );
};

export default News;
