import React, { useEffect, useRef } from 'react';
import PER from '../components/PerformanceOverview';
import PTGR from '../components/PTGR';
import InvestmentPerformance from '../components/InvestmentPerformance';

const CPM = () => {
  // Create a reference for the PER component
  const perRef = useRef(null);

  useEffect(() => {
    // Scroll to the PER component when the page loads
    if (perRef.current) {
      perRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, []); // Empty dependency array ensures it runs only once when the component mounts

  return (
    <div>

      <PTGR />
      {/* Assign the reference to the PER component */}
      <div ref={perRef}>
        <PER />
        <InvestmentPerformance/>
      </div>
    </div>
  );
};

export default CPM;
